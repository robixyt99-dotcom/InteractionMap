// карта
const map = L.map('map').setView([55.06, 51.25], 10);

// слой OpenStreetMap
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png')
  .addTo(map);

// данные по селам
const villages = [
  {
    name: "Новошешминск",
    coords: [55.066, 51.233],
    img: "img/novoshes.jpg",
    short: "Российский радиоинженер, лауреат Государственной премии СССР",
    bioLink: "bio-novoshes.html"
  },
  {
    name: "Утяшкино",
    coords: [55.10, 51.32],
    img: "img/utyashkino.jpg",
    short: "Заслуженный деятель науки Республики Татарстан.",
    bioLink: "bio-utyashkino.html"
  },
  {
    name: "Зирекле",
    coords: [55.02, 51.18],
    img: "img/zirekle.jpg",
    short: "Ученый-врач, уролог, доктор медицинских наук, профессор.",
    bioLink: "bio-zirekle.html"
  }
];

// создание кружков
villages.forEach(v => {
  const circle = L.circleMarker(v.coords, {
    radius: 10,
    color: "blue",
    fillColor: "skyblue",
    fillOpacity: 0.8
  }).addTo(map);

  circle.on("click", () => {
    // анимация приближения
    map.flyTo(v.coords, 13, { duration: 2 });

    // popup
    circle.bindPopup(`
  <div class="popup">
    <img src="${v.img}">
    <h4>${v.name}</h4>
    <p>${v.short}</p>
    <a href="${v.bioLink}" target="_blank">
      Перейти к биографии
    </a>
  </div>
 `).openPopup();
  });
});

// функции биографии
function openBio(name, text) {
  document.getElementById("bioName").innerText = name;
  document.getElementById("bioText").innerText = text;
  document.getElementById("bioModal").style.display = "block";
}

function closeBio() {
  document.getElementById("bioModal").style.display = "none";
}